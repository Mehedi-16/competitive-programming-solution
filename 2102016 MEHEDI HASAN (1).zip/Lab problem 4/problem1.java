public class problem1 {
    public static void main(String args[]) {
        String s ="25";
        int i = Integer.parseInt(s);
        System.out.println("Integer value is: "+i);
    }
}